
---

## Data Cleaning & Processing
- Converted timestamps to readable date format.
- Extracted date only for merging datasets.
- Merged historical trades with sentiment data using the date.
- Dropped trades without sentiment classification.
- Saved the cleaned dataset as `merged_clean.csv`.

---

## Analysis Performed
- **Total Trades vs Sentiment:** Shows how trading activity varies with market sentiment.
- **Total PnL vs Sentiment:** Observes trader profits and losses based on market mood.
- **Trade Size vs Sentiment:** Indicates position size trends relative to sentiment.
- **Win Rate vs Sentiment:** Determines how sentiment affects trade success rate.

All metrics were visualized using Python (Matplotlib/Seaborn) in the notebook.

---

## Insights / Observations
- On **Greed** days, the total number of trades is highest, indicating more market activity during positive sentiment.
- Traders tend to take **larger positions** on Extreme Greed days.
- Win rate is **highest on Greed days** and lowest on Fear days.
- Profits are generally higher during positive market sentiment days.

*(For full insights, see the `analysis_notebook.ipynb`.)*

---

## How to Use
1. Open `analysis_notebook.ipynb` in Jupyter Notebook or JupyterLab.
2. Ensure the `data/` folder is in the same directory as the notebook.
3. Run all cells to reproduce the analysis and plots.

---

## Author
Khushi Rawat – Data Science Intern
